const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const crypto = require('crypto');
const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static(path.join(__dirname, 'public')));
const rooms = new Map();
const bank = [
 ['How socially acceptable is this?','Clapping when the plane lands',31],['How embarrassing is this?','Accidentally liking a photo from 2016',96],['How suspicious is this?','Your friend saying “trust me” before a bad idea',91],['How legendary is this?','Finding a twenty in your winter coat',85],['How brave is this?','Asking for extra ketchup at a fancy restaurant',34],['How cursed is this?','A pizza topped with cereal',94],['How cool is this?','Your teacher casually doing a backflip',98],['How annoying is this?','Someone playing videos out loud on the bus',93],['How chaotic is this?','A family group chat with 47 notifications',86],['How impressive is this?','A dog that can skateboard',88],['How awkward is this?','Saying you too when the waiter says enjoy your meal',90],['How funny is this?','Your grandma using brainrot slang perfectly',96],['How much do people enjoy this?','A rainy Sunday morning',42],['How cool is this?','A skateboard trick',78],['How overrated is this?','A viral dance trend',68],['How scary is this?','A roller coaster at night',76],['How nostalgic is this?','Playing Minecraft with old friends',92],['How impressive is this?','Solving a Rubik’s Cube in 20 seconds',90],['How delicious is this?','Cold pizza for breakfast',57],['How chaotic is this?','A group chat with 100 unread messages',87],['How futuristic is this?','Self-driving cars',81],['How difficult is this?','Learning a new language',83],['How popular is this?','Watching sports highlights',71],['How relaxing is this?','Listening to rain',89],['How awkward is this?','Waving at someone who was waving behind you',94],['How iconic is this?','The first iPhone',96],['How exciting is this?','Finding money in an old jacket',86],['How risky is this?','Sending a text to the wrong person',67],['How useful is this?','A phone at 1% battery',18],['How entertaining is this?','A very bad movie with friends',75],['How mysterious is this?','An unexplored cave',91],['How satisfying is this?','Getting the last puzzle piece in place',95]
];

const CATEGORIES=['Random Mix','Video Games','History','Math','Science','Movies & TV','Sports','Music','Animals','Food & Drinks'];
const categoryPrompts={
 'Video Games':['How legendary is finding diamonds in Minecraft?','How stressful is the final circle in Fortnite?','How satisfying is beating a boss with one HP left?','How embarrassing is losing to your little sibling in Mario Kart?','How powerful is a fully upgraded Pokémon team?','How scary is hearing a creeper behind you?'],
 'History':['How chaotic would living through the fall of Rome be?','How impressive were ancient Egyptian pyramids?','How awkward would a medieval royal banquet be today?','How terrifying would a Viking raid feel?','How futuristic would a printing press seem in the year 1400?','How difficult would it be to survive a winter in the Ice Age?'],
 'Math':['How satisfying is solving a hard equation on the first try?','How confusing is dividing by zero?','How impressive is calculating a tip instantly in your head?','How annoying is a math test with no calculator?','How lucky is guessing a multiple-choice math answer correctly?','How difficult is explaining fractions to a pirate?'],
 'Science':['How mind-blowing is the size of the observable universe?','How scary would it be to see a black hole up close?','How impressive is a rocket landing itself?','How chaotic is a baking-soda volcano that overflows the table?','How weird is an octopus having three hearts?','How useful would a real invisibility cloak be?'],
 'Movies & TV':['How iconic is a movie villain with an unforgettable entrance?','How annoying is a cliffhanger at the end of a season?','How funny is a movie with terrible special effects?','How emotional is the final episode of your favorite show?','How cool is a superhero landing in slow motion?','How awkward is watching a romance scene with your parents?'],
 'Sports':['How legendary is a last-second game-winning touchdown?','How embarrassing is missing a wide-open layup?','How impressive is a bicycle-kick soccer goal?','How intense is a penalty shootout in a championship?','How satisfying is hitting a home run?','How chaotic is a mascot running onto the field?'],
 'Music':['How embarrassing is singing the wrong lyrics confidently?','How legendary is hearing your favorite song live?','How annoying is a song stuck in your head all day?','How impressive is playing piano with your eyes closed?','How awkward is your playlist shuffling to a meme song at a party?','How satisfying is a perfect beat drop?'],
 'Animals':['How intimidating is a goose chasing you?','How impressive is a dolphin learning tricks?','How cute is a sleepy red panda?','How chaotic would a raccoon be as a roommate?','How scary is a shark fin in the water?','How clever is an octopus escaping an aquarium?'],
 'Food & Drinks':['How cursed is pineapple on cereal?','How satisfying is pizza after a long day?','How spicy is biting a raw ghost pepper?','How embarrassing is dropping your ice cream immediately?','How luxurious is breakfast in bed?','How chaotic is a taco that falls apart on the first bite?']
};
const categoryBank=Object.fromEntries(Object.entries(categoryPrompts).map(([key,items])=>[key,items.map((prompt,i)=>({category:key,prompt,answer:[8,9,7,6,8,9,5,10,4][(i+key.length)%9]+0,unit:'out of 10',source:'Game-designed subjective rating'}))]));
function pickCategoryQuestion(roomCode,category){
 const options=category==='Random Mix'?Object.values(categoryBank).flat():categoryBank[category];
 const used=usedQuestions.get(roomCode)||new Set();let available=options.filter(q=>!used.has(q.category+'|'+q.prompt));
 if(!available.length){for(const q of options)used.delete(q.category+'|'+q.prompt);available=options}
 const q=available[crypto.randomInt(available.length)];used.add(q.category+'|'+q.prompt);usedQuestions.set(roomCode,used);return {...q};
}

const clean = (s,max=40) => typeof s==='string' ? s.trim().replace(/[<>\u0000-\u001f]/g,'').slice(0,max) : '';
const usedQuestions=new Map();
function pickQuestion(roomCode){const used=usedQuestions.get(roomCode)||new Set();let available=bank.filter(q=>!used.has(q[0]+'|'+q[1]));if(!available.length){used.clear();available=bank}const q=available[crypto.randomInt(available.length)];used.add(q[0]+'|'+q[1]);usedQuestions.set(roomCode,used);return {category:'THE SPECTRUM',prompt:q[0]+' '+q[1],answer:Math.max(1,Math.min(10,Math.round(q[2]/10))),unit:'out of 10',source:'Game-designed subjective rating'};}
async function makeQuestion(roomCode='_solo',category=null){
 if(category&&!CATEGORIES.includes(category))category='Random Mix';
 if(category&&!process.env.OPENAI_API_KEY)return pickCategoryQuestion(roomCode,category);
 if(!process.env.OPENAI_API_KEY)return pickQuestion(roomCode);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),6500);
 try{
  const response=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',signal:controller.signal,headers:{'Content-Type':'application/json',Authorization:'Bearer '+process.env.OPENAI_API_KEY},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4o-mini',response_format:{type:'json_object'},messages:[{role:'system',content:'Return JSON keys prompt,answer. Create one hilarious, surprising, debate-provoking Wavelength-style SUBJECTIVE rating prompt for a social party game. Prefer relatable absurd dilemmas, internet culture, unexpected comparisons, and harmless awkward social situations. Avoid repetitive generic questions. Example: "How cool is this? Finding an old game console". Randomize across movies, music, memes, history, science, sports, food, games, everyday life. answer must be an integer 1 through 10 representing a playful subjective target, NOT an actual poll. Keep family friendly. Avoid numerical trivia. Prompt should describe one thing to rate on a spectrum from 1 to 10.'},{role:'user',content:category?'Generate one creative spectrum rating question strictly about '+category+'.':'Generate one new creative spectrum rating question.'}]})});
  if(!response.ok)throw Error('AI request failed');const data=await response.json();const q=JSON.parse(data.choices[0].message.content);
  if(!Number.isInteger(q.answer)||q.answer<1||q.answer>10||typeof q.prompt!=='string'||q.prompt.length<12)throw Error('Invalid question');
  return {category:category&&category!=='Random Mix'?category:'THE SPECTRUM',prompt:clean(q.prompt,180),answer:q.answer,unit:'out of 10',source:'AI-estimated subjective rating'};
 }catch{return category?pickCategoryQuestion(roomCode,category):pickQuestion(roomCode)}finally{clearTimeout(timer)}
}
app.get('/api/solo-question', async (req,res)=>{try{const q=await makeQuestion();res.set('Cache-Control','no-store').json(q)}catch{res.status(500).json({error:'Unable to load question'})}});
const code = () => {let c; do {c=crypto.randomBytes(3).toString('hex').toUpperCase()} while(rooms.has(c)); return c};
const robotAvatar = () => crypto.randomInt(8);
const player = (r,id) => r.players.find(p=>p.id===id);
const active = r => r.players.filter(p=>p.connected);
const publicLobbies=()=>[...rooms.values()].filter(r=>r.phase==='lobby'&&r.visibility==='public'&&active(r).length<12).map(r=>({code:r.code,host:active(r)[0]?.name||'Host',category:r.category,players:active(r).length,maxPlayers:12,createdAt:r.createdAt})).sort((a,b)=>b.createdAt-a.createdAt).slice(0,100);
function broadcastLobbies(){io.emit('lobbies',publicLobbies())}
const send=r=>{
 io.to(r.code).emit('state',{
 code:r.code,phase:r.phase,round:r.round,maxRounds:r.maxRounds,category:r.category,categoryVotes:Object.fromEntries(CATEGORIES.map(c=>[c,[...(r.categoryVotes||new Map()).values()].filter(v=>v===c).length])),votesCast:r.categoryVotes?.size||0,
 players:r.players.map(p=>({id:p.id,name:p.name,score:p.score,avatar:p.avatar,connected:p.connected,categoryVote:r.categoryVotes?.get(p.id)||null,guessed:r.guesses.has(p.id),skipVoted:r.skipVotes?.has(p.id)||false})),
 host:active(r)[0]?.id,clueMaster:r.setter,question:r.question?{category:r.question.category,prompt:r.phase==='clue'&&r.setter!==undefined?'Clue Master is writing a clue…':r.question.prompt,unit:r.question.unit,source:r.question.source}:null,
 guessesCount:r.guesses.size,needed:active(r).filter(p=>p.id!==r.setter).length,skipCount:r.skipVotes?.size||0,results:r.phase==='results'?r.results:null,
 answer:r.phase==='results'||r.phase==='finished'?r.question?.answer:null,deadline:r.deadline
 });
};
function beginGuessing(r){
 if(r.phase!=='preview')return;r.phase='guessing';r.skipVotes=new Set();r.deadline=Date.now()+60000;send(r);
 const round=r.round;setTimeout(()=>{if(rooms.get(r.code)===r&&r.round===round&&r.phase==='guessing')reveal(r)},60000);
}
function beginPreview(r){
 if(r.phase!=='clue')return;
 if(!r.question.clue)r.question.clue='A mysterious thing';
 if(!Number.isInteger(r.question.answer))r.question.answer=5;
 r.question.prompt=r.question.clue;r.phase='preview';r.skipVotes=new Set();r.deadline=Date.now()+7000;send(r);
 const round=r.round;setTimeout(()=>{if(rooms.get(r.code)===r&&r.round===round&&r.phase==='preview')beginGuessing(r)},7000);
}
async function startRound(r){
 if(active(r).length<2){r.phase='lobby';send(r);return}
 r.round++;r.phase='loading';r.deadline=null;r.guesses=new Map();r.skipVotes=new Set();r.results=null;r.question=null;send(r);
 const round=r.round;const q=await makeQuestion(r.code,r.category);
 if(rooms.get(r.code)!==r||r.round!==round||r.phase!=='loading')return;
 const eligible=active(r);r.setter=eligible[(r.round-1)%eligible.length].id;
 r.question={category:q.category,prompt:q.prompt,clue:'',answer:null,unit:'out of 10',source:'Clue Master selected target'};
 r.phase='clue';r.deadline=Date.now()+30000;send(r);
 setTimeout(()=>{if(rooms.get(r.code)===r&&r.round===round&&r.phase==='clue')beginPreview(r)},30000);
}

function reveal(r){
 if(r.phase!=='guessing')return;
 r.results=active(r).map(p=>{
  const guess=r.guesses.get(p.id),distance=p.id===r.setter||guess===undefined?null:Math.abs(guess-r.question.answer);
  const points=distance===null?0:Math.max(0,Math.round(100*(1-distance/9)));
  p.score+=points;return {id:p.id,name:p.name,guess:guess??null,distance,points};
 }).sort((a,b)=>b.points-a.points);
 r.phase='results';r.skipVotes=new Set();r.deadline=null;send(r);
}
function findRoom(socket){const r=rooms.get(socket.data.room);return r&&player(r,socket.id)?.connected?r:null}
function safeAvatar(a){return {color:Math.max(0,Math.min(11,Math.trunc(Number(a?.color)||0))),eyes:Math.max(0,Math.min(7,Math.trunc(Number(a?.eyes)||0))),hat:Math.max(0,Math.min(7,Math.trunc(Number(a?.hat)||0)))}}
function ackError(ack,message){if(typeof ack==='function')ack({ok:false,error:message})}
// Admin PIN must be set privately on the server. Never trust a client-side PIN.
const adminPin=process.env.ADMIN_PIN;
const adminAttempts=new Map();
io.on('connection',socket=>{
 socket.on('adminLogin',({pin}={},ack)=>{
  const r=findRoom(socket);if(!r)return ackError(ack,'Join a room first.');
  const a=adminAttempts.get(socket.id)||{count:0};if(a.count>=5)return ackError(ack,'Too many attempts. Reconnect later.');
  if(!adminPin||String(pin)!==adminPin){a.count++;adminAttempts.set(socket.id,a);return ackError(ack,'Incorrect admin code or admin access not configured.')}
  socket.data.admin=true;adminAttempts.delete(socket.id);ack?.({ok:true});
 });
 socket.on('adminAnnouncement',({message}={},ack)=>{
  const r=findRoom(socket);if(!r||!socket.data.admin)return ackError(ack,'Admin authorization required.');
  const msg=clean(message,180);if(!msg)return ackError(ack,'Type a message.');
  const now=Date.now();if(now-(socket.data.lastAnnouncement||0)<3000)return ackError(ack,'Wait before sending another announcement.');
  socket.data.lastAnnouncement=now;io.to(r.code).emit('adminAnnouncement',{message:msg,from:'ROOM ADMIN'});ack?.({ok:true});
 });
 socket.on('adminSetCategory',({category}={},ack)=>{
  const r=findRoom(socket);if(!r||!socket.data.admin)return ackError(ack,'Admin authorization required.');
  if(r.phase!=='lobby')return ackError(ack,'Category changes are available in the lobby.');
  if(!CATEGORIES.includes(category))return ackError(ack,'Invalid category.');
  r.category=category;send(r);broadcastLobbies();ack?.({ok:true});
 });

 socket.on('listLobbies',(_,ack)=>{ack?.({ok:true,lobbies:publicLobbies()})});
 socket.on('create',({name,avatar,visibility}={},ack)=>{
  const n=clean(name,20);if(!n)return ackError(ack,'Enter a name.');
  const c=code();const r={code:c,players:[{id:socket.id,name:n,score:0,avatar:safeAvatar(avatar),connected:true}],phase:'lobby',visibility:visibility==='private'?'private':'public',createdAt:Date.now(),category:'Random Mix',categoryVotes:new Map(),round:0,maxRounds:5,guesses:new Map(),setter:null};
  rooms.set(c,r);socket.join(c);socket.data.room=c;ack?.({ok:true,code:c});send(r);broadcastLobbies();
 });
 socket.on('join',({name,code:roomCode,avatar}={},ack)=>{
  const n=clean(name,20),c=clean(roomCode,6).toUpperCase(),r=rooms.get(c);
  if(!n)return ackError(ack,'Enter a name.');
  if(!r)return ackError(ack,'Room not found.');
  if(r.phase!=='lobby')return ackError(ack,'Game already started. Join the next game.');
  if(active(r).length>=12)return ackError(ack,'Room is full (12 players).');
  if(socket.data.room)return ackError(ack,'Already in a room.');
  r.players.push({id:socket.id,name:n,score:0,avatar:safeAvatar(avatar),connected:true});socket.join(c);socket.data.room=c;ack?.({ok:true,code:c});send(r);broadcastLobbies();
 });
 socket.on('voteCategory',({category}={},ack)=>{
  const r=findRoom(socket);if(!r)return ackError(ack,'Room unavailable.');
  if(r.phase!=='lobby')return ackError(ack,'Voting is only available in the lobby.');
  if(!CATEGORIES.includes(category))return ackError(ack,'Invalid category.');
  if(!player(r,socket.id)?.connected)return ackError(ack,'You must be in the room to vote.');
  if(!r.categoryVotes)r.categoryVotes=new Map();
  r.categoryVotes.set(socket.id,category);
  const counts=new Map(CATEGORIES.map(c=>[c,0]));for(const vote of r.categoryVotes.values())counts.set(vote,(counts.get(vote)||0)+1);
  const max=Math.max(...counts.values());
  const leaders=CATEGORIES.filter(c=>counts.get(c)===max);
  // A tied vote keeps the previously leading category if possible; otherwise Random Mix or first category.
  r.category=leaders.includes(r.category)?r.category:leaders.includes('Random Mix')?'Random Mix':leaders[0];
  send(r);broadcastLobbies();ack?.({ok:true});
 });
 socket.on('start',(_,ack)=>{
  const r=findRoom(socket);if(!r)return ackError(ack,'Room unavailable.');
  if(active(r)[0]?.id!==socket.id)return ackError(ack,'Only the host can start.');
  if(r.phase!=='lobby')return ackError(ack,'Already started.');
  if(active(r).length<2)return ackError(ack,'You need at least 2 players.');
  if(active(r).some(p=>!r.categoryVotes?.has(p.id)))return ackError(ack,'Wait for every player to vote on a category.');
  r.round=0;r.players.forEach(p=>p.score=0);startRound(r);broadcastLobbies();ack?.({ok:true});
 });
 socket.on('submitClue',({number,clue}={},ack)=>{
  const r=findRoom(socket);if(!r||r.phase!=='clue'||r.setter!==socket.id)return ackError(ack,'Only the current Clue Master can submit.');
  const n=Number(number),c=clean(clue,140);
  if(!Number.isInteger(n)||n<1||n>10)return ackError(ack,'Choose a number from 1 to 10.');
  if(c.length<3)return ackError(ack,'Write a clue of at least 3 characters.');
  r.question.answer=n;r.question.clue=c;r.question.prompt=c;ack?.({ok:true});beginPreview(r);
 });
 socket.on('skip',(_,ack)=>{
  const r=findRoom(socket);if(!r||!['clue','preview','guessing'].includes(r.phase))return ackError(ack,'Nothing to skip right now.');
  if(r.phase==='guessing'&&socket.id!==r.setter&&!r.guesses.has(socket.id))return ackError(ack,'Lock in your guess before voting to skip.');
  r.skipVotes.add(socket.id);ack?.({ok:true});
  if(active(r).every(p=>r.skipVotes.has(p.id))){if(r.phase==='clue')beginPreview(r);else if(r.phase==='preview')beginGuessing(r);else reveal(r)}else send(r);
 });
 socket.on('guess',({guess}={},ack)=>{
  const r=findRoom(socket);if(!r||r.phase!=='guessing'||socket.id===r.setter)return ackError(ack,'Cannot guess now.');
  const g=Number(guess);if(!Number.isInteger(g)||g<1||g>10)return ackError(ack,'Invalid guess.');
  if(r.guesses.has(socket.id))return ackError(ack,'Already guessed.');
  r.guesses.set(socket.id,g);ack?.({ok:true});
  if(active(r).filter(p=>p.id!==r.setter).every(p=>r.guesses.has(p.id)))reveal(r);else send(r);
 });
 socket.on('next',(_,ack)=>{
  const r=findRoom(socket);if(!r||r.phase!=='results')return ackError(ack,'Round not finished.');
  if(active(r)[0]?.id!==socket.id)return ackError(ack,'Only the host can continue.');
  if(r.round>=r.maxRounds){r.phase='finished';send(r)}else startRound(r);
  ack?.({ok:true});
 });
 socket.on('restart',(_,ack)=>{
  const r=findRoom(socket);if(!r||r.phase!=='finished')return ackError(ack,'Game not finished.');
  if(active(r)[0]?.id!==socket.id)return ackError(ack,'Only the host can restart.');
  r.phase='lobby';r.round=0;usedQuestions.delete(r.code);r.players=r.players.filter(p=>p.connected);r.players.forEach(p=>p.score=0);send(r);broadcastLobbies();ack?.({ok:true});
 });
 socket.on('disconnect',()=>{adminAttempts.delete(socket.id);
  const r=rooms.get(socket.data.room);if(!r)return;
  const p=player(r,socket.id);if(p)p.connected=false;r.categoryVotes?.delete(p.id);
  if(!active(r).length){rooms.delete(r.code);usedQuestions.delete(r.code);broadcastLobbies();return}
  if(r.phase==='guessing'&&active(r).filter(x=>x.id!==r.setter).every(x=>r.guesses.has(x.id)))reveal(r);
  else if(['clue','preview','guessing'].includes(r.phase)&&active(r).every(x=>r.skipVotes?.has(x.id))){if(r.phase==='clue')beginPreview(r);else if(r.phase==='clue')beginPreview(r);else if(r.phase==='preview')beginGuessing(r);else reveal(r);}
  else send(r);
  broadcastLobbies();
 });
});
const PORT=process.env.PORT||3000;server.listen(PORT,()=>console.log(`Magic Number running on http://localhost:${PORT}`));
