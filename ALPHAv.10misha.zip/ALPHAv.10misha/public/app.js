
// Local progression: XP and cosmetic unlocks are saved per browser, not server-verified.
const $=id=>document.getElementById(id);
const XP_KEY='magic_moon_xp_v2', ACH_KEY='magic_moon_achievements_v2';
function currentXP(){return Math.max(0,Number(localStorage.getItem(XP_KEY))||0)}
function levelFor(xp){return 1+Math.floor(Math.sqrt(xp/120))}
function levelFloor(level){return 120*(level-1)*(level-1)}
function unlockText(){const l=levelFor(currentXP());return ['Level 2: Crown','Level 3: Emerald armor','Level 4: Wizard hat','Level 5: Gold armor','Level 6: Crimson armor'].filter((_,i)=>l<i+2).slice(0,2).join(' · ')||'All featured cosmetics unlocked!'}
function renderProgress(){const xp=currentXP(),level=levelFor(xp),start=levelFloor(level),end=levelFloor(level+1);$('xp-level').textContent=level;$('xp-total').textContent=xp+' XP';$('xp-title').textContent=level>=6?'MOON LEGEND':level>=4?'STAR KNIGHT':level>=2?'MOON SCOUT':'MOON APPRENTICE';$('xp-fill').style.width=(100*(xp-start)/(end-start))+'%';$('xp-unlocks').textContent='NEXT UNLOCKS: '+unlockText();}
function toast(msg){const el=document.createElement('div');el.className='achievement-toast';el.textContent='✦ '+msg;document.body.append(el);setTimeout(()=>el.remove(),3500)}
function awardXP(amount,achievement){const old=currentXP(),before=levelFor(old);let earned=Math.max(0,Math.round(amount));if(achievement){let ach=[];try{ach=JSON.parse(localStorage.getItem(ACH_KEY)||'[]')}catch{}if(!ach.includes(achievement)){ach.push(achievement);localStorage.setItem(ACH_KEY,JSON.stringify(ach));earned+=75;toast('ACHIEVEMENT: '+achievement+' · +75 XP')}}localStorage.setItem(XP_KEY,old+earned);renderProgress();if(levelFor(old+earned)>before)toast('LEVEL UP! LEVEL '+levelFor(old+earned));}
const cosmeticRules={color:[1,1,3,1,5,6,2,3,4,5,6,8],eyes:[1,1,2,3,2,4,5,7],hat:[1,2,3,4,3,5,6,8]};
function renderCosmetics(){const level=levelFor(currentXP());for(const [key,id] of [['color','avatar-color'],['eyes','avatar-eyes'],['hat','avatar-hat']]){const select=$(id);for(const opt of select.options){const needed=cosmeticRules[key][Number(opt.value)]||1;opt.disabled=level<needed;opt.textContent=opt.textContent.replace(/ \[LV.*/,'')+(level<needed?' [LV '+needed+']':'')}if(select.selectedOptions[0]?.disabled)select.value='0'}$('cosmetic-locks').innerHTML='<strong>✦ MOON REWARDS</strong><p>Earn XP from Solo Quest and multiplayer rounds to unlock armor, eyes, and headgear.</p><p>LEVEL '+level+' · '+currentXP()+' XP</p><p>Achievements: '+escapeHTML((()=>{try{return JSON.parse(localStorage.getItem(ACH_KEY)||'[]').join(' · ')||'None yet'}catch{return 'None yet'}})())+'</p>';}
function pin(guess,name,index){const node=document.createElement('div');node.className='reveal-pin';node.style.setProperty('--x',((guess-1)/9*100)+'%');node.style.setProperty('--c',['#9ceaff','#f9b5e6','#c6ff9a','#ffcb8e','#c4b4ff'][index%5]);node.title=name+' guessed '+guess;node.textContent=String(guess);return node}
function drawReveal(trackId,results,answer,statusId){const track=$(trackId);track.replaceChildren();const target=document.createElement('div');target.className='reveal-target hidden-target';target.style.setProperty('--x',((answer-1)/9*100)+'%');track.append(target);results.filter(r=>r.guess!==null).forEach((r,i)=>track.append(pin(r.guess,r.name,i)));if(statusId)$(statusId).textContent='Finding the secret number…';setTimeout(()=>{target.classList.remove('hidden-target');if(statusId)$(statusId).textContent='★ SECRET NUMBER: '+answer+' ★'},1100)}
renderProgress();

const socket=io();let state=null;let guess=5;let target=5;
function show(id,yes){$(id).classList.toggle('hidden',!yes)}
function err(id,msg){$(id).textContent=msg;show(id,!!msg)}
function call(event,data={}){socket.emit(event,data,response=>{if(!response?.ok)err(state?'gameerror':'homeerror',response?.error||'Something went wrong.');else err(state?'gameerror':'homeerror','')})}
$('create').onclick=()=>{err('homeerror','');socket.emit('create',{name:$('name').value,avatar:avatarConfig(),visibility:$('room-visibility').value},r=>{if(!r?.ok)err('homeerror',r?.error||'Unable to create room')})};
$('join').onclick=()=>{err('homeerror','');socket.emit('join',{name:$('name').value,code:$('joincode').value,avatar:avatarConfig()},r=>{if(!r?.ok)err('homeerror',r?.error||'Unable to join room')})};
$('joincode').addEventListener('keydown',e=>{if(e.key==='Enter')$('join').click()});
$('copy').onclick=async()=>{const link=location.origin+'/?room='+state.code;try{await navigator.clipboard.writeText(link);$('copy').textContent='✓ LINK COPIED';setTimeout(()=>$('copy').textContent='⧉ COPY INVITE',1700)}catch{prompt('Copy this invite link:',link)}};
$('room-category').onchange=()=>call('voteCategory',{category:$('room-category').value});$('start').onclick=()=>call('start');$('submitguess').onclick=()=>call('guess',{guess:Number($('guessinput').value)});$('next').onclick=()=>call('next');$('restart').onclick=()=>call('restart');$('skippreview').onclick=()=>call('skip');$('skipclue').onclick=()=>call('skip');$('submitclue').onclick=()=>call('submitClue',{number:Number($('cluenumber').value),clue:$('cluetext').value});$('cluenumber').oninput=()=>{$('cluevalue').textContent=$('cluenumber').value};$('skipguess').onclick=()=>call('skip');
const escapeHTML=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const robotColors=['#a86bf5','#4ca5f5','#43d6a2','#f17ebd','#f4c35e','#ed6279','#ff8c42','#e5e5e5','#151515','#4ef7ff','#b8ff40','#f4aaff'];
function avatarConfig(){try{const a=JSON.parse(localStorage.getItem('magic_pixel_avatar')||'{}');return {color:Math.max(0,Math.min(11,Number(a.color)||0)),eyes:Math.max(0,Math.min(7,Number(a.eyes)||0)),hat:Math.max(0,Math.min(7,Number(a.hat)||0))}}catch{return {color:0,eyes:0,hat:0}}}
function robotSvg(config){const a=(typeof config==='object'&&config!==null)?config:{color:Number(config)||0,eyes:0,hat:0};const c=robotColors[(Number(a.color)||0)%robotColors.length],eyes=Number(a.eyes)||0,hat=Number(a.hat)||0;const eyeParts=[`<rect x="13" y="23" width="5" height="7" fill="#5bf0ff"/><rect x="30" y="23" width="5" height="7" fill="#5bf0ff"/>`,`<rect x="20" y="23" width="8" height="8" fill="#5bf0ff"/>`,`<rect x="13" y="28" width="7" height="2" fill="#5bf0ff"/><rect x="28" y="28" width="7" height="2" fill="#5bf0ff"/>`,`<path d="M13 25h6v4h-6zm16 0h6v4h-6z" fill="#5bf0ff"/>`,`<rect x="13" y="24" width="7" height="7" fill="#ffea4e"/><rect x="28" y="24" width="7" height="7" fill="#ffea4e"/>`,`<rect x="12" y="25" width="24" height="4" fill="#ff5050"/>`,`<rect x="13" y="22" width="7" height="9" fill="#aaff44"/><rect x="28" y="22" width="7" height="9" fill="#aaff44"/>`,`<rect x="14" y="25" width="5" height="5" fill="white"/><rect x="29" y="25" width="5" height="5" fill="white"/>`];const hats=[`<rect x="22" y="4" width="4" height="9" fill="#d9b5ff"/><rect x="20" y="2" width="8" height="4" fill="#5bf0ff"/>`,`<path d="M10 12V4l9 5 5-8 5 8 9-5v8z" fill="#ffdb67"/>`,`<path d="M9 14V3h5v7h20V3h5v11z" fill="#d9b5ff"/>`,`<path d="M7 14h34v-4H29L23 0 14 10H7z" fill="#a776f6"/>`,`<rect x="5" y="7" width="38" height="7" fill="#f2b63d"/>`,`<path d="M8 14L15 2h18l7 12z" fill="#8af2ff"/>`,`<rect x="11" y="3" width="26" height="12" fill="#ff68b7"/>`,`<path d="M4 13h40v-4H30V2H18v7H4z" fill="#e9e9e9"/>`];return `<svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" shape-rendering="crispEdges" aria-hidden="true"><rect x="7" y="15" width="34" height="29" fill="#090d21"/><rect x="5" y="20" width="5" height="16" fill="${c}"/><rect x="38" y="20" width="5" height="16" fill="${c}"/><rect x="9" y="13" width="30" height="30" fill="${c}"/><rect x="12" y="19" width="24" height="18" fill="#10152d"/>${eyeParts[eyes%8]}<rect x="20" y="34" width="8" height="2" fill="#a9b9ff"/>${hats[hat%8]}<rect x="13" y="40" width="22" height="3" fill="#3d2c69"/></svg>`}
function rows(players,withScores=true){return players.map(p=>`<div class="player"><div><span class="avatar">${robotSvg(p.avatar)}</span><strong>${escapeHTML(p.name)}</strong>${!p.connected?' <small class="muted">(offline)</small>':''}</div>${withScores?`<span class="score">${p.score} pts</span>`:`<span class="pill">${p.connected?'READY':'OFFLINE'}</span>`}</div>`).join('')}
$('guessinput').addEventListener('input',()=>{$('guessvalue').textContent=$('guessinput').value});
let oldPhase='',oldRound=0;
socket.on('state',s=>{
 const first=!state;state=s;show('home',false);show('game',true);$('roomcode').textContent=s.code;
 $('phase').textContent=s.phase.toUpperCase();$('round').textContent=s.phase==='lobby'?'Waiting for players':`Round ${s.round} / ${s.maxRounds}`;
 for(const p of ['lobby','loading','clue','preview','guessing','results','finished'])show(p,s.phase===p);
 const mine=s.players.find(p=>p.id===socket.id),host=s.host===socket.id;
 $('room-category').value=mine?.categoryVote||'Random Mix';$('room-category').disabled=false;const total=s.players.filter(p=>p.connected).length;$('category-note').textContent=`${s.votesCast||0}/${total} voted · Leading: ${s.category||'Random Mix'}${mine?.categoryVote?' · Your vote: '+mine.categoryVote:''}`;const votes=$('category-vote-results');votes.replaceChildren();for(const [category,count] of Object.entries(s.categoryVotes||{})){const line=document.createElement('div');line.className='category-vote-line';const name=document.createElement('span');name.textContent=category;const amount=document.createElement('strong');amount.textContent=count+' vote'+(count===1?'':'s');line.append(name,amount);if(category===s.category)line.classList.add('leading-category');votes.append(line)};$('count').textContent=s.players.filter(p=>p.connected).length+'/12';$('lobbyplayers').innerHTML=rows(s.players,false);
 show('start',host);$('start').disabled=s.players.filter(p=>p.connected).length<2||s.votesCast<s.players.filter(p=>p.connected).length;
 $('hostnote').textContent=host?'Start once everyone has voted. Ties keep the current leader.':'Vote for a category, then wait for the host to start.';
 $('leaderboard').innerHTML=rows([...s.players].sort((a,b)=>b.score-a.score));$('scorecount').textContent=s.players.filter(p=>p.connected).length+' players';
 if(s.phase==='clue'){
 const master=s.players.find(p=>p.id===s.clueMaster);const isMaster=s.clueMaster===socket.id;
 $('cluecategory').textContent=s.category||'Random Mix';$('cluemasterlabel').textContent=isMaster?'You are the Clue Master!':`${master?.name||'Someone'} is the Clue Master`;
 $('cluehelp').textContent=isMaster?'Topic: '+(s.category||'Random Mix')+'. Suggested prompt: '+(s.question?.prompt||'')+' Choose a secret number and write a related clue. Your number stays hidden until the reveal.':'Wait for the Clue Master to choose a secret number and write a clue.';
 show('clueform',isMaster);$('skipclue').textContent=`${s.skipCount||0} / ${s.players.filter(p=>p.connected).length} voted to skip`; $('skipclue').disabled=mine?.skipVoted||false;
 if(oldPhase!==s.phase){$('cluenumber').value=5;$('cluevalue').textContent='5';$('cluetext').value='';}
 }
 if(s.phase==='preview'){$('previewcategory').textContent=s.question?.category||'Random topic';$('previewprompt').textContent=s.question?.prompt||'Loading question…';$('skippreview').textContent=`${s.skipCount||0} / ${s.needed} voted to skip · SKIP WAIT`; $('skippreview').disabled=s.players.find(p=>p.id===socket.id)?.skipVoted||false}
 if(s.phase==='guessing'){
 $('guesscategory').textContent=s.question?.category||'Random topic';$('guessprompt').textContent=s.question?.prompt||'';
 const master=s.clueMaster===socket.id;const guessed=mine?.guessed||false;show('guessform',!guessed&&!master);show('guesswait',guessed||master);
 $('guesswait').textContent=master?'🤖 You are the Clue Master — watch your friends guess!':'✓ Answer locked! Waiting for other players…';
 $('guessedcount').textContent=`${s.guessesCount} / ${s.needed} answers locked in`; $('skipguess').textContent=`${s.skipCount||0} / ${s.needed} voted to reveal early`;show('skipguess',guessed||master);$('skipguess').disabled=mine?.skipVoted||false;
 if(oldPhase!==s.phase||oldRound!==s.round)$('guessinput').value='5';$('guessvalue').textContent=$('guessinput').value;
 }
 if(s.phase==='results'){
 if(oldPhase!=='results'||oldRound!==s.round){drawReveal('reveal-track',s.results||[],s.answer,'reveal-status');const mineResult=(s.results||[]).find(p=>p.id===socket.id);if(mineResult&&mineResult.guess!==null)awardXP(25+Math.round(mineResult.points/2),mineResult.distance===0?'PERFECT ALIGNMENT':null)}
 $('revealnum').textContent=s.answer;$('answerunit').textContent=s.question?.unit||'';
 $('resultslist').innerHTML=(s.results||[]).map((r,i)=>`<div class="resultrow"><div><strong>${i===0?'🥇 ':''}${escapeHTML(r.name)}</strong><div class="muted">${r.guess===null?'No guess':`Guessed ${r.guess} · ${r.distance} away`}</div></div><div class="score">+${r.points}</div></div>`).join('');
 show('next',host);$('next').textContent=s.round>=s.maxRounds?'SEE FINAL SCORES →':'NEXT ROUND →';
 }
 if(s.phase==='finished'){$('finalscores').innerHTML=rows([...s.players].sort((a,b)=>b.score-a.score));show('restart',host)}
 oldPhase=s.phase;oldRound=s.round;
});
setInterval(()=>{if(state?.deadline){const remaining=Math.max(0,Math.ceil((state.deadline-Date.now())/1000))+'s';if(state.phase==='guessing')$('timer').textContent=remaining;if(state.phase==='preview')$('settimer').textContent=remaining;if(state.phase==='clue')$('cluetimer').textContent=remaining}},250);
socket.on('disconnect',()=>{err('gameerror','Connection lost. Refresh the page to reconnect.');err('homeerror','Server connection lost. Please refresh.');});
socket.on('connect',()=>err('gameerror',''));
const invite=new URLSearchParams(location.search).get('room');if(invite)$('joincode').value=invite.slice(0,6).toUpperCase();

// Solo mode uses the same AI/fallback question service as multiplayer.
let soloRound=0,soloScore=0,soloQuestion=null,soloPhase='',soloDeadline=0,soloInterval=null,soloLocked=false;
function soloShow(id,yes){show('solo-'+id,yes)}
function soloStop(){if(soloInterval!==null){clearInterval(soloInterval);soloInterval=null}}
function soloView(view){for(const id of ['loading','question','result','finished'])soloShow(id,id===view)}
function soloHome(){soloStop();show('solo',false);show('home',true);soloQuestion=null}
$('solo-home').onclick=soloHome;
$('solo-start').onclick=()=>{show('home',false);show('game',false);show('solo',true);soloRound=0;soloScore=0;soloNext()};
$('solo-again').onclick=()=>{soloRound=0;soloScore=0;soloNext()};
function soloTick(){const left=Math.max(0,Math.ceil((soloDeadline-Date.now())/1000));$('solo-timer').textContent=left+'s';if(left===0){soloStop();if(soloPhase==='preview')soloBeginGuess();else if(soloPhase==='guessing')soloReveal()}}
function soloTimer(seconds){soloStop();soloDeadline=Date.now()+seconds*1000;soloTick();soloInterval=setInterval(soloTick,200)}
async function soloNext(){
 soloStop();if(soloRound>=5){soloView('finished');$('solo-final').textContent=soloScore;const best=Math.max(soloScore,Number(localStorage.getItem('magic_solo_best'))||0);localStorage.setItem('magic_solo_best',best);$('solo-rank').textContent=soloScore>=450?'✦ LEGENDARY ORACLE':soloScore>=350?'✦ MASTER GUESSER':soloScore>=250?'✦ RISING SEER':'✦ APPRENTICE';$('solo-record').textContent='PERSONAL BEST: '+best;return}
 soloRound++;soloLocked=false;soloView('loading');err('solo-error','');$('solo-round').textContent=`ROUND ${soloRound} / 5`;$('solo-score').textContent=soloScore+' PTS';$('solo-best').textContent='BEST '+(Number(localStorage.getItem('magic_solo_best'))||0);
 try{const response=await fetch('/api/solo-question',{cache:'no-store'});if(!response.ok)throw Error('Server error');const q=await response.json();if(!Number.isInteger(q.answer))throw Error('Invalid question');if(!$('solo').classList.contains('hidden')){soloQuestion=q;soloView('question');$('solo-category').textContent=q.category||'Random';$('solo-prompt').textContent=q.prompt;$('solo-input').value='5';$('solo-value').textContent='5';soloShow('entry',false);soloShow('skip',true);$('solo-stage').textContent='READ THE QUESTION';$('solo-instructions').textContent='You have 7 seconds to read the clue before guessing begins.';soloPhase='preview';soloTimer(7)}}catch{soloView('loading');err('solo-error','Could not load a question. Check that the server is running.');$('solo-loading').innerHTML='Unable to load question. <button id="solo-retry" class="secondary">TRY AGAIN</button>';$('solo-retry').onclick=()=>{soloRound--;soloNext()}}
}
function soloBeginGuess(){if(soloPhase!=='preview')return;soloPhase='guessing';soloShow('skip',false);soloShow('entry',true);$('solo-stage').textContent='GUESS THE NUMBER';$('solo-instructions').textContent='You have 60 seconds to lock in your answer.';soloTimer(60);$('solo-input').focus()}
function soloReveal(){if(soloLocked||!soloQuestion)return;soloLocked=true;soloStop();soloPhase='result';const value=$('solo-input').value;const valid=value.trim()!==''&&Number.isInteger(Number(value))&&Number(value)>=1&&Number(value)<=10;const guess=valid?Number(value):null;const distance=guess===null?null:Math.abs(guess-soloQuestion.answer);const earned=distance===null?0:Math.max(0,Math.round(100*(1-distance/9)));soloScore+=earned;awardXP(20+Math.round(earned/2),distance===0?'SOLO PERFECTION':null);soloView('result');drawReveal('solo-reveal-track',[{name:'You',guess}],soloQuestion.answer);$('solo-answer').textContent=soloQuestion.answer;$('solo-detail').textContent=(soloQuestion.unit||'')+' · '+(guess===null?'No answer submitted':`You guessed ${guess} (${distance} away)`);$('solo-earned').textContent='+'+earned+' POINTS';$('solo-score').textContent=soloScore+' PTS';$('solo-best').textContent='BEST '+(Number(localStorage.getItem('magic_solo_best'))||0);$('solo-next').textContent=soloRound===5?'SEE FINAL SCORE →':'NEXT ROUND →'}
$('solo-submit').onclick=soloReveal;$('solo-input').addEventListener('keydown',e=>{if(e.key==='Enter'&&soloPhase==='guessing')soloReveal()});$('solo-next').onclick=soloNext;

$('solo-input').addEventListener('input',()=>{$('solo-value').textContent=$('solo-input').value});
$('solo-skip').onclick=()=>{if(soloPhase==='preview')soloBeginGuess()};



// Pixel avatar creator: saved locally and sent to the room server.
const avatarSelects=['avatar-color','avatar-eyes','avatar-hat'];
function avatarRefresh(){const a={color:Number($('avatar-color').value),eyes:Number($('avatar-eyes').value),hat:Number($('avatar-hat').value)};$('avatar-preview').innerHTML=robotSvg(a)}
$('avatar-open').onclick=()=>{show('home',false);show('avatar-editor',true);const a=avatarConfig();$('avatar-color').value=a.color;$('avatar-eyes').value=a.eyes;$('avatar-hat').value=a.hat;renderCosmetics();avatarRefresh()};
$('avatar-back').onclick=()=>{show('avatar-editor',false);show('home',true)};
avatarSelects.forEach(id=>$(id).addEventListener('change',avatarRefresh));
$('avatar-save').onclick=()=>{renderCosmetics();localStorage.setItem('magic_pixel_avatar',JSON.stringify({color:Number($('avatar-color').value),eyes:Number($('avatar-eyes').value),hat:Number($('avatar-hat').value)}));show('avatar-editor',false);show('home',true)};

// Room-scoped admin announcements: visible overlays, not remote keyboard control.
const adminBtn=document.getElementById('nav-admin');
if(adminBtn)adminBtn.addEventListener('click',()=>{document.getElementById('admin-panel').classList.toggle('hidden')});
const adminStatus=document.getElementById('admin-status');
document.getElementById('admin-login').addEventListener('click',()=>socket.emit('adminLogin',{pin:document.getElementById('admin-pin').value},r=>{adminStatus.textContent=r?.ok?'ADMIN UNLOCKED':(r?.error||'Login failed');if(r?.ok)document.getElementById('admin-actions').classList.remove('hidden')}));
document.getElementById('admin-send').addEventListener('click',()=>socket.emit('adminAnnouncement',{message:document.getElementById('admin-message').value},r=>{adminStatus.textContent=r?.ok?'Announcement sent':(r?.error||'Unable to send')}));
socket.on('adminAnnouncement',({message,from})=>{const notice=document.createElement('div');notice.className='admin-overlay';const heading=document.createElement('strong');heading.textContent=from||'ADMIN';const body=document.createElement('p');body.textContent=message;notice.append(heading,body);document.body.append(notice);setTimeout(()=>notice.remove(),8500)});

// Live public lobby browser: server controls the authoritative list and join permissions.
function refreshLobbies(){socket.emit('listLobbies',{},r=>{if(r?.ok)renderLobbies(r.lobbies||[]);else $('lobby-browser').textContent='Unable to load rooms. Check your connection.'})}
function renderLobbies(lobbies){const panel=$('lobby-browser');panel.replaceChildren();if(!lobbies.length){const p=document.createElement('p');p.className='hint';p.textContent='No open public rooms yet. Create one and invite friends!';panel.append(p);return}for(const lobby of lobbies){const row=document.createElement('div');row.className='row';row.style.cssText='align-items:center;justify-content:space-between;gap:10px;padding:10px;border:1px solid var(--border, #777);flex-wrap:wrap';const detail=document.createElement('div');const title=document.createElement('strong');title.textContent=lobby.host+' · '+lobby.category;const meta=document.createElement('div');meta.className='hint';meta.textContent=lobby.players+'/'+lobby.maxPlayers+' players · '+lobby.code;detail.append(title,meta);const btn=document.createElement('button');btn.type='button';btn.className='secondary';btn.textContent='JOIN';btn.addEventListener('click',()=>{socket.emit('join',{name:$('name').value,code:lobby.code,avatar:avatarConfig()},r=>{if(!r?.ok)err('homeerror',r?.error||'Unable to join room')})});row.append(detail,btn);panel.append(row)}}
$('refresh-lobbies').addEventListener('click',refreshLobbies);
socket.on('lobbies',renderLobbies);
socket.on('connect',refreshLobbies);
if(socket.connected)refreshLobbies();
