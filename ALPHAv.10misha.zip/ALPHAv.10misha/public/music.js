/* Magic Number: original procedural chiptune. No external audio files or copyrighted songs. */
(() => {
  'use strict';
  const toggle = document.getElementById('setting-music');
  const volume = document.getElementById('setting-music-volume');
  const volumeText = document.getElementById('music-volume-value');
  const status = document.getElementById('music-status');
  if (!toggle || !volume) return;
  const read = (k, fallback) => { try { return localStorage.getItem(k) ?? fallback; } catch { return fallback; } };
  const store = (k, v) => { try { localStorage.setItem(k, String(v)); } catch {} };
  let ctx, master, timer, step = 0, nextTime = 0;
  const bpm = 108, beat = 60 / bpm / 2;
  const notes = [0, 7, 12, 7, 3, 7, 10, 7, 0, 7, 12, 15, 3, 7, 10, 7,
                 5, 12, 17, 12, 8, 12, 15, 12, 3, 10, 15, 10, 7, 10, 12, 10];
  const bass = [0, 0, 5, 5, 3, 3, 7, 7];
  const freq = (midi) => 440 * Math.pow(2, (midi - 69) / 12);
  function tone(midi, at, length, type, level) {
    if (!ctx || !master) return;
    const oscillator = ctx.createOscillator(), envelope = ctx.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(freq(midi), at);
    envelope.gain.setValueAtTime(0.0001, at);
    envelope.gain.exponentialRampToValueAtTime(level, at + 0.012);
    envelope.gain.exponentialRampToValueAtTime(0.0001, at + length);
    oscillator.connect(envelope).connect(master);
    oscillator.start(at); oscillator.stop(at + length + 0.02);
  }
  function schedule() {
    if (!ctx || ctx.state !== 'running') return;
    while (nextTime < ctx.currentTime + 0.18) {
      const i = step % notes.length;
      tone(60 + notes[i], nextTime, beat * 0.76, 'square', 0.13);
      if (step % 4 === 0) tone(36 + bass[Math.floor(step / 4) % bass.length], nextTime, beat * 3.1, 'triangle', 0.28);
      if (step % 8 === 4) tone(72 + notes[i], nextTime, beat * 1.3, 'sine', 0.055);
      nextTime += beat; step++;
    }
  }
  function setVolume() {
    const v = Number(volume.value);
    volumeText.textContent = v + '%'; store('magic_music_volume', v);
    if (master && ctx) master.gain.setTargetAtTime(v / 100 * 0.38, ctx.currentTime, 0.04);
  }
  async function start() {
    try {
      if (!ctx) {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClass) throw new Error('Audio is not supported by this browser.');
        ctx = new AudioContextClass();
        master = ctx.createGain(); master.connect(ctx.destination);
      }
      setVolume(); await ctx.resume();
      if (!toggle.checked) { await ctx.suspend(); return; }
      if (timer) clearInterval(timer);
      nextTime = ctx.currentTime + 0.06;
      schedule(); timer = setInterval(schedule, 75);
      status.textContent = '♫ Now playing: Pixel Dreams (original chiptune)';
    } catch (error) {
      toggle.checked = false; store('magic_music_enabled', false);
      status.textContent = error.message || 'Music could not start.';
    }
  }
  async function stop() {
    if (timer) clearInterval(timer); timer = null;
    if (ctx && ctx.state === 'running') await ctx.suspend();
    status.textContent = 'Music is off.';
  }
  toggle.checked = read('magic_music_enabled', 'false') === 'true';
  volume.value = read('magic_music_volume', '35'); setVolume();
  if (toggle.checked) status.textContent = 'Click anywhere to resume your music.';
  toggle.addEventListener('change', () => {
    store('magic_music_enabled', toggle.checked);
    if (toggle.checked) start(); else stop();
  });
  volume.addEventListener('input', setVolume);
  // Browser autoplay policies require a user gesture before playing audio.
  document.addEventListener('pointerdown', () => {
    if (toggle.checked && (!ctx || ctx.state !== 'running')) start();
  });
  document.addEventListener('keydown', () => {
    if (toggle.checked && (!ctx || ctx.state !== 'running')) start();
  });
  document.getElementById('settings-reset')?.addEventListener('click', () => {
    toggle.checked = false; store('magic_music_enabled', false);
    volume.value = '35'; setVolume(); stop();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && ctx?.state === 'running') stop();
    else if (!document.hidden && toggle.checked) status.textContent = 'Click to resume music.';
  });
})();
