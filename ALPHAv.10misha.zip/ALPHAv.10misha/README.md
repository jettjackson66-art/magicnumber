Magic Number ALPHAv.07misha

New: 12 armor colors, 8 eye styles, 8 headgear styles, room-scoped admin announcement overlay.

IMPORTANT: Set ADMIN_PIN=0011 as a private server environment variable before launching. Never place the PIN in public HTML/JS. A four-digit PIN is weak; use a longer secret for any public deployment. Admin announcements are visible overlays, not remote typing or keyboard access.

Install: npm install; run: npm start. Test multiplayer before production.


Alpha .08: Public online lobby browser, live lobby updates, public/private room visibility, one-click joining, and manual refresh. Public rooms are listed only while waiting for players; private rooms remain invite-code only. Requires a Node.js host with WebSocket support and one persistent server process. Rooms are in memory and reset on server restart.


## Alpha .09: category voting
Every connected lobby player can vote for any of the 10 options, including Random Mix, and change their vote until the match starts. Live tallies and the leading category appear to everyone. The host can start only after all connected players vote. On ties, the previous leader remains if tied; otherwise Random Mix wins if tied, otherwise the first category in the list wins. Votes are cleared on disconnection and new rooms start with no votes.

## Music (Alpha .10)
Settings now has an opt-in background music toggle and volume slider. The soundtrack is an original, procedurally synthesized chiptune using the browser Web Audio API; no copyrighted audio or third-party service is required. Audio starts only after a user interaction, is muted by default for new users, and the preference is saved locally. Music pauses when the tab is hidden.
